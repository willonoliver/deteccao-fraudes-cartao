# Detecção de Fraudes em Cartões de Crédito

Projeto de classificação para identificar transações fraudulentas em uma base de cartão de crédito altamente desbalanceada.

## Objetivo

Detectar a classe `Class = 1` (fraude). Como as fraudes representam uma parcela muito pequena dos registros, a acurácia isolada pode ser enganosa: um classificador que prevê todas as transações como normais pode alcançar uma acurácia alta e não detectar nenhuma fraude.

Por isso, a avaliação prioriza **recall, precisão e F1 da classe fraude**, além de ROC-AUC e Average Precision (área sob a curva Precision-Recall).

## Dados

O notebook carrega o CSV diretamente da URL:

https://storage.googleapis.com/download.tensorflow.org/data/creditcard.csv

O arquivo não deve ser versionado no GitHub.

## Etapas

1. Exploração da base e proporção das classes.
2. Transformação de `Amount` com `numpy.log1p`.
3. Divisão treino/teste estratificada.
4. Comparação entre Regressão Logística, Random Forest e XGBoost.
5. Relatórios, matrizes de confusão e curvas ROC e Precision-Recall.
6. Avaliação dos limiares 0,5 e 0,3.
7. Busca de hiperparâmetros com `GridSearchCV`, usando recall como critério.
8. Importância das variáveis e explicação com SHAP.

A padronização é aplicada em pipelines para que o scaler seja ajustado somente nos dados de treino. O Random Forest e a Regressão Logística usam `class_weight='balanced'`; o XGBoost usa `scale_pos_weight`.

## Resultados

Execute o notebook e preencha esta seção com os resultados efetivamente obtidos:

| Modelo | Precisão fraude | Recall fraude | F1 fraude |
|---|---:|---:|---:|
| Regressão Logística | — | — | — |
| Random Forest | — | — | — |
| XGBoost | — | — | — |
| Random Forest ajustado | — | — | — |

**Limiar escolhido:** preencher após comparar o custo de falsos positivos e falsos negativos.

**SHAP:** descrever as variáveis que mais contribuíram para as previsões após executar a análise.

## Diferenças e melhorias

Este projeto reúne os três modelos solicitados, mantém o pré-processamento dentro de pipelines quando aplicável, compara o limiar de decisão e inclui uma etapa de explicabilidade com SHAP. Os resultados não são pré-preenchidos: devem ser registrados após a execução para evitar apresentar métricas inventadas.

## Como executar

Recomendado: Google Colab ou Python 3.10+.

```bash
pip install -r requirements.txt
jupyter notebook deteccao_fraudes_cartao.ipynb
```

No Colab, faça upload do notebook e execute as células em ordem. É necessária conexão com a internet para baixar a base.

## Limitações

O desempenho em uma divisão de teste não garante desempenho em produção. Um sistema real exige validação temporal, monitoramento de mudança de comportamento, análise de falsos positivos, segurança e revisão humana dos alertas.
